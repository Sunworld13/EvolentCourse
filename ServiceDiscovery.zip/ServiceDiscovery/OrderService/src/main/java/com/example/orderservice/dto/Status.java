package com.example.orderservice.dto;

public enum Status {
    NEW,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
